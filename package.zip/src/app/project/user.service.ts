import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map } from "rxjs/operators";
@Injectable()
export class UserService {
    URL = "";
    constructor(private http: HttpClient) {
        this.URL = "http://localhost:3000/api/user/";
    }
    login(obj): any {
        return this.http.post(this.URL + 'login', obj).pipe(map(x => {
            return x;
        }))
    }
    saveData(obj): any {
        return this.http.post(this.URL + 'createUser', obj).pipe(map(x => {
            return x;
        }))
    }
    getAllData(): any {
        return this.http.get(this.URL + 'getAllUser').pipe(map(x => {
            return x;
        }))
    }
    deleteDataById(userId): any {
        return this.http.delete(this.URL + 'deleteUser/' + userId).pipe(map(x => {
            return x;
        }))
    }
    showDataById(userId): any {
        return this.http.get(this.URL + 'getUserById/' + userId).pipe(map(x => {
            return x;
        }))
    }
}