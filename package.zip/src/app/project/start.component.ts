import { Component } from "@angular/core";

@Component({
    selector:'starttag',
    templateUrl:'./start.component.html'
})

export class StartComponent{
    title = "Hello Start Component";
}