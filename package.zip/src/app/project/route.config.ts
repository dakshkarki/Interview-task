import { Routes } from "@angular/router" ;
import { LoginComponent } from './login.component';
import { RegistrationComponent } from './registration.component';
import { ThankyouComponent } from './thankyou.component';
import { StartComponent } from './start.component';

export const routes:Routes = [
    {path:'', component:LoginComponent},
    {path:'login', component:LoginComponent},
    {path:'registration', component:RegistrationComponent},
    {path:'thankyou', component:ThankyouComponent},   
    {path:'**', component:LoginComponent}
]