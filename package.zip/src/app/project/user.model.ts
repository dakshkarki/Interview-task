export class User {
    userId: Number;
    uFirstName: String;
    uLastName: String;
    uEmailId: String;
    uMobileNo: String;
    uAddress: String;
    uPassword: String;
    constructor() {
           
    }
}