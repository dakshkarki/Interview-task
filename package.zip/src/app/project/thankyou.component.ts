import { Component } from "@angular/core";

@Component({
    selector:'thankyoutag',
    templateUrl:'./thankyou.component.html'
})

export class ThankyouComponent{
    title = "Hello Thankyou Component"
}
