import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { User } from './user.model';
import { UserService } from './user.service';

@Component({
    selector: 'logintag',
    templateUrl: './login.component.html'
})

export class LoginComponent {
    title = "Hello Login Component"
    user: User = new User();
    constructor(private route: Router, private userService: UserService) {
    }

    go() {
        this.route.navigate(['./registration']);
    }
    login() {
        this.userService.login(this.user).subscribe(x => {
            if (x.userResponse.message != "warning") {
                this.route.navigate(['./thankyou']);
            }
            else {
                alert('User is not Valid!!');
            }
        })
    }
}