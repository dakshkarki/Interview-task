import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router"
import { StartComponent } from './start.component';
import { routes } from "./route.config";
import { LoginComponent } from './login.component';
import { RegistrationComponent } from './registration.component';
import { ThankyouComponent } from './thankyou.component';
import { HttpClientModule } from "@angular/common/http";
import { UserService } from './user.service';
import { FormsModule } from "@angular/forms";

@NgModule({
    declarations: [StartComponent, LoginComponent, RegistrationComponent, ThankyouComponent],
    imports: [BrowserModule, FormsModule, HttpClientModule, RouterModule.forRoot(routes)],
    providers: [UserService],
    bootstrap: [StartComponent]
})

export class ProjectModule {

}