import { Component, OnInit } from "@angular/core";
import { UserService } from './user.service';
import { User } from './user.model';

@Component({
    selector: 'registrationtag',
    templateUrl: './registration.component.html'
})

export class RegistrationComponent implements OnInit {
    title = "Hello Registration Component";
    user: User = new User();
    userData = [];
    btnText = "Save";
    constructor(private userService: UserService) {

    }
    ngOnInit() {

    }
    saveData() {
        this.userService.saveData(this.user).subscribe(x => {
            if (x.userResponse.message == "success") {
                this.getAllData();
            }
            else {
                alert(x.userResponse.message);
            }
        })
    }
    cancel() {
        this.user = new User();
        this.btnText = "Save";
    }
    editData(userId) {
        this.user = this.userData.find(x => x.userId == userId);
        this.btnText = 'Update';
    }
    ShowData(userId) {
        this.user = this.userData.find(x => x.userId == userId);
    }
    DeleteData(userId) {
        this.userService.deleteDataById(userId).subscribe(x => {
            if (x.userResponse.message == "success") {
                this.getAllData();
            }
            else {
                alert(x.userResponse.message);
            }
        })
    }
    showById() {
        this.userData = [];
        //this.userData = this.userData.filter(k => k.userId == this.user.userId);
        this.userService.showDataById(this.user.userId).subscribe(x => {
            if (x.userResponse.message == "success") {
                this.userData = x.userResponse.userData;
            }
            else {
                alert(x.userResponse.message);
            }
        })
    }
    getAllData() {
        this.userService.getAllData().subscribe(x => {
            if (x.userResponse.message == "success") {
                this.userData = x.userResponse.userData;
            }
            else {
                alert(x.userResponse.message);
            }
        })
    }
}